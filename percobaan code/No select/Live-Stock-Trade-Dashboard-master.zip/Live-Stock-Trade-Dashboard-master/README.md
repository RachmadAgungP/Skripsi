# Live Stock Trading Dashboard

Web server providing a dashboard of live trade information from company database, including recent trades and total vega and theta traded (in plots).  Updates in real time.

Made with Plotly, specifically a very early version of Plotly Dash.

Created according to spec for summer 2017 internship at Bell Curve Capital.